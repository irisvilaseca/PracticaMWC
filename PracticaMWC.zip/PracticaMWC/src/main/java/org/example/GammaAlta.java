package org.example;

public interface GammaAlta {
    public boolean isGammaAlta();
}
