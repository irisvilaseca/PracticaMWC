package org.example;

public interface DispositiuInterface {
    double calculaPreuFinal();
}
